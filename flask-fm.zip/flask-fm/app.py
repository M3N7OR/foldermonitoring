import time
from flask import Flask, render_template_string
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import mysql.connector

# Flask app setup
app = Flask(__name__)

# MySQL connection details
DB_CONFIG = {
    'user': 'root',          # Replace with your MySQL usernam
    'host': 'localhost',     # Replace with your MySQL host
    'database': 'file_monitoring',  # Replace with your MySQL database name
}

# Initialize MySQL database
def init_db():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                event_type VARCHAR(50),
                src_path TEXT,
                event_description TEXT
            )
        """)
        connection.commit()
        cursor.close()
        connection.close()
    except mysql.connector.Error as err:
        print(f"Error initializing database: {err}")

# Function to insert log into MySQL
def log_to_mysql(event_type, src_path, event_description):
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO documents_log (event_type, src_path, event_description)
            VALUES (%s, %s, %s)
        """, (event_type, src_path, event_description))
        connection.commit()
        cursor.close()
        connection.close()
    except mysql.connector.Error as err:
        print(f"Error inserting log: {err}")

# Custom event handler to log events to MySQL
class MyLoggingEventHandler(FileSystemEventHandler):
    def on_modified(self, event):
        log_to_mysql("modified", event.src_path, f"Modified: {event.src_path}")
    
    def on_created(self, event):
        log_to_mysql("created", event.src_path, f"Created: {event.src_path}")
    
    def on_deleted(self, event):
        log_to_mysql("deleted", event.src_path, f"Deleted: {event.src_path}")
    
    def on_moved(self, event):
        log_to_mysql("moved", event.src_path, f"Moved from {event.src_path} to {event.dest_path}")

# Flask route to display logs
@app.route('/')
def show_logs():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM documents_logs ORDER BY timestamp DESC")
        logs = cursor.fetchall()
        cursor.close()
        connection.close()
    except mysql.connector.Error as err:
        return f"Error fetching logs: {err}"

    # HTML template as a string
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>File Monitoring Logs</title>
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th, td {
                padding: 8px;
                text-align: left;
                border-bottom: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
        </style>
    </head>
    <body>
        <h1>File Monitoring Logs</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Timestamp</th>
                    <th>Event Type</th>
                    <th>Source Path</th>
                </tr>
            </thead>
            <tbody>
                {% for log in logs %}
                <tr>
                    <td>{{ log[0] }}</td>
                    <td>{{ log[1] }}</td>
                    <td>{{ log[2] }}</td>
                    <td>{{ log[3] }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </body>
    </html>
    """
    return render_template_string(html_template, logs=logs)

# Start the watchdog observer
def start_observer():
    path = "C:/Users/M3N7OR/Desktop/Folder-monitoring"  # Change this to your desired directory
    event_handler = MyLoggingEventHandler()
    observer = Observer()
    observer.schedule(event_handler, path, recursive=True)
    observer.start()
    print("Monitoring started...")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("Monitoring stopped.")
    observer.join()

if __name__ == "__main__":
    # Initialize the database
    init_db()

    # Start the observer in a separate thread
    from threading import Thread
    observer_thread = Thread(target=start_observer)
    observer_thread.daemon = True
    observer_thread.start()

    # Run the Flask app
    app.run(debug=True)